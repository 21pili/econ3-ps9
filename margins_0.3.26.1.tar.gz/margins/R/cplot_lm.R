#' @rdname cplot
#' @export
cplot.lm <- cplot.default
