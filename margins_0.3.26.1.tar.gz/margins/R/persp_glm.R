#' @rdname persp
#' @export
persp.glm <- persp.lm
