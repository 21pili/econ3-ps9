#' @rdname marginal_effects
#' @export
marginal_effects.loess <- marginal_effects.default
