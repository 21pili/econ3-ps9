#' @rdname persp
#' @export
persp.loess <- persp.lm
