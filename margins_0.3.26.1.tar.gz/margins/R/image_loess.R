#' @rdname persp
#' @export
image.loess <- image.lm
