#' @rdname cplot
#' @export
cplot.loess <- cplot.default
