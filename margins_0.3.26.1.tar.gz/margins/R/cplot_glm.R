#' @rdname cplot
#' @export
cplot.glm <- cplot.default
