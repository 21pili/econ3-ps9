#' @rdname margins
#' @export
margins.lm <- margins.glm
