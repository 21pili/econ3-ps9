#' @rdname persp
#' @export
image.glm <- image.lm
