#' @rdname prediction
#' @export
prediction.mclogit <- prediction.default
